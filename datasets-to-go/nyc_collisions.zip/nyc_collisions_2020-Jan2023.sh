#! /bin-bash

curl -XDELETE localhost:9200/nyc_collision

curl -XPUT localhost:9200/nyc_collision -H "Content-Type: application/json" --data-binary '
{"settings":{"number_of_replicas":0,"number_of_shards":1},"mappings":{"properties":{"@timestamp":{"type":"date"},"district":{"type":"keyword"},"zipcode":{"type":"keyword"},"latitude":{"type":"keyword"},"longitude":{"type":"keyword"},"location":{"type":"geo_point"},"persons_injured":{"type":"integer"},"persons_killed":{"type":"integer"},"pedestrians_injured":{"type":"integer"},"pedestrians_killed":{"type":"integer"},"cyclist_injured":{"type":"integer"},"cyclist_killed":{"type":"integer"},"motorist_injured":{"type":"integer"},"motorist_killed":{"type":"integer"},"collision_id":{"type":"keyword"}}}}
'

elasticdump --input "csv://./nyc_collisions_2020-Jan2023-data.csv" --output=http://localhost:9200/nyc_collision --csvDelimiter ";" --limit 50000